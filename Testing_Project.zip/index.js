const express = require("express");
const app = express();
const port = 3080;
const cors = require("cors");
const mysql = require("mysql");

app.use(cors());
app.use(express.json());

// database

const db = mysql.createConnection({
  user: "root",
  host: "localhost",
  password: "",
  database: "mysqlcrud",
});

app.get("/allemployees", (req, res) => {
  db.query("SELECT * FROM employees", (err, result) => {
    if (err) {
      console.log(err);
    } else {
      res.send(result);
    }
  });
});

app.get("/alldepartments", (req, res) => {
  db.query("SELECT * FROM departments", (err, result) => {
    if (err) {
      console.log(err);
    } else {
      res.send(result);
    }
  });
});

app.get("/", (req, res) => {
  res.send("Hello World!");
});

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`);
});
